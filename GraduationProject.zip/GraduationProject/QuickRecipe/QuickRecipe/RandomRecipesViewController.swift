//
//  RandomRecipesViewController.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/4/23.
//

import UIKit

class RandomRecipesViewController: UIViewController , UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout
{
    @IBOutlet weak var collectionView: UICollectionView!
    var dataController : DataController!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        displaySpoonacularApiClient()
        displayRightBarButton(imageName: "button3.png")
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController!.navigationBar.topItem?.title = "Select your Recipe"

        BarButton.barButton(viewController: self , Enabled :true , color :UIColor.blue)
    
    }
    
    override func viewDidDisappear(_ animated: Bool)
    {
        super.viewDidDisappear(animated)
        BarButton.barButton(viewController: self , Enabled :false , color :UIColor.clear)
    }
    
    func displaySpoonacularApiClient()
    {
        SpoonacularApiClient.random
        {
            (randomRecipes, error) in
            
            RandomDataModel.randomDataList = randomRecipes

            if (RandomDataModel.randomDataList == [] || error != nil)
            {
                DispatchQueue.main.async
                {
                    Alert.globalAlert(title: "Error", message: "Cant Display Images", viewController: self)
                }
            }

            else
            {
                DispatchQueue.main.async
                {
                    self.collectionView.reloadData()
                }
            }
        }
    }
    
    func getIndexForCollectView(collectionView : UICollectionView) -> NSIndexPath
    {
        let iPath = collectionView.indexPathsForSelectedItems
        let indexPath : NSIndexPath = iPath![0] as NSIndexPath
        return indexPath
    }
    
    @objc func refrashButton()
    {
        displaySpoonacularApiClient()
        self.collectionView.reloadData()
    }
    
    func displayRightBarButton(imageName : String)
    {
        let barImage = UIImage(named: imageName)
        let rightBarButton = UIBarButtonItem(image: barImage, style: .plain, target: self, action: #selector(refrashButton))
        self.navigationController?.navigationBar.topItem?.rightBarButtonItem = rightBarButton
        

    }
    
    // MARK: - UICollectionViewDelegateFlowLayout Functions
    
    // the width And height size for  Cell And How cells to display in collectionView
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: self.view.frame.width * 0.499, height: self.view.frame.width * 0.46)
    }
    
    // the Space betwwn up And Down Cell
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat
    {
        return 1
    }
    
    //the Space betwwn right And left Cell
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat
    {
        return 0.20
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets
    {
        return UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 10)
    }
    
    // MARK: - UICollectionView Functions
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return RandomDataModel.randomDataList.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SpoonacularCollectionViewCell", for: indexPath) as! CollectionViewCell
        let DataModel = RandomDataModel.randomDataList[indexPath.row]
        cell.iamgeView.image = UIImage(named: "placeholder")
        cell.nameLabel.text  = DataModel.title
        cell.timeLable.text  = "cooking Time : \((DataModel.readyInMinutes)) Mins"
        
        let urlString = DataModel.image
        let imageURL = URL(string: urlString)
        DispatchQueue.main.async
        {
            cell.iamgeView.loadImage(fromURL: imageURL!, placeHolderImage: "placeholder")
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        performSegue(withIdentifier: "RecipeDetailSegue", sender: indexPath)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "RecipeDetailSegue")
        {
            guard let controller = segue.destination as? RecipeDetailViewController else { return }

            let indexPath = getIndexForCollectView(collectionView: self.collectionView)
            let recipeDetail = RandomDataModel.randomDataList[(indexPath.row)]
            controller.recipeName = recipeDetail.title
            controller.recipeImage = recipeDetail.image
            controller.recipeId = recipeDetail.id
            controller.dataController = dataController
            controller.coredataChecker = false
        }
    }
}
    

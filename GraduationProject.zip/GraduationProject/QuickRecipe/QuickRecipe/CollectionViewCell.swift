//
//  CollectionViewCell.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/5/23.
//

import UIKit

class CollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var iamgeView: LazyDownloadingImage!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var timeLable: UILabel!
    
    override func prepareForReuse()
    {
        super.prepareForReuse()
        self.iamgeView.image = nil // remove this Line of you dont want to use LazyDownloadingImage class
    }
    
    // Questions
    // MARK: - : rounded corners for UIImageView
    override var bounds: CGRect
    {
        didSet
        {
            self.layoutIfNeeded()
        }
    }
    
    override func layoutSubviews()
    {
        super.layoutSubviews()
        self.setCircularImageView()
    }
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        
        self.iamgeView.layer.masksToBounds = true
    }
    
    func setCircularImageView()
    {
        self.iamgeView.layer.cornerRadius = CGFloat(round(Float(self.iamgeView.frame.width / 8.0)))
    }

}

//
//  RecipeDetailViewController.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 2/2/23.
//

import UIKit
import CoreData

class RecipeDetailViewController: UIViewController
{
    @IBOutlet weak var recipeImageView: UIImageView!
    @IBOutlet weak var recipeNameLabel: UILabel!
    @IBOutlet weak var recipeCookingTimeLabel: UILabel!
    @IBOutlet weak var recipeServingsLabel: UILabel!
    @IBOutlet weak var recipeIngredientLabel: UILabel!
    @IBOutlet weak var recipeInstructionsLabel: UILabel!
    @IBOutlet weak var saveButtonDisplay: UIButton!
    
    var recipeImage : String?
    var recipeName  : String?
    var recipeinstructions : String?
    var recipeId :Int?

    var dataController : DataController!
    var recipe:RecipeDB!
    var coredataChecker : Bool!
        
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        if(coredataChecker != true)
        {
            displayRecipeInformations(recipeId : recipeId!)
            displayRecipeIngredients(recipeId  : recipeId!)
            recipeNameLabel.text  = recipeName
            recipeImageView.image = imageConverter(urlString: recipeImage!)
        }
        
        else
        {
            self.recipeNameLabel.text = recipe.recipeTitle
            self.recipeCookingTimeLabel.text = recipe.recipeTime
            self.recipeServingsLabel.text = recipe.numberOfServings
            self.recipeImageView.image = UIImage(data: recipe.recipeImage!)
            self.recipeInstructionsLabel.text = recipe.recipeInstructions!
            self.recipeIngredientLabel.text = recipe.recipeIngredients!
            self.saveButtonDisplay.isHidden = true
        }
    }
    
    func imageConverter(urlString : String ) -> UIImage
    {
        var newUIImage = UIImage()
        let urlString = urlString
        let imageURL = URL(string: urlString)
        if let iamgeData = try? Data(contentsOf : imageURL!)
        {
            
            newUIImage = UIImage(data : iamgeData)!
        }
        return newUIImage
    }
    
    func displayRecipeInformations(recipeId : Int)
    {
        SpoonacularApiClient.instructions(recipeId: recipeId)
        {
            (InstructionsResponse, error) in
            DispatchQueue.main.async
            {
                self.recipeCookingTimeLabel.text  = "Time : \(String(InstructionsResponse?.readyInMinutes ?? 0))"
                self.recipeInstructionsLabel.text = "Instructions :\(InstructionsResponse?.instructions ?? " ")"
                self.recipeServingsLabel.text     = "Servings :\(String(InstructionsResponse!.servings))"
            }
        }
    }
    
    func displayRecipeIngredients(recipeId : Int)
    {
        var ingredientsApiRespons = IngredientsDataModel.IngredientsDataList
        SpoonacularApiClient.ingredients(recipeId: recipeId)
        {
            (IngredientsResponse, error) in
            ingredientsApiRespons = IngredientsResponse
            
            // Questions
            let ingredientsDisplay = ingredientsApiRespons.map
            {
                (ingredients) -> String in
                return String(ingredients.name + " " + ingredients.amount.metric.unit + " \n " )
            }.joined(separator: " ")
            
            DispatchQueue.main.async
            {
                self.recipeIngredientLabel.text = "ingredients :\(ingredientsDisplay)"
            }
        }
    }
    
    @IBAction func saveRecip(_ sender: Any)
    {
        saveRecipeToCoreData(recipeId: self.recipeId!, recipeTitle: self.recipeName!,
                             recipeTime: self.recipeCookingTimeLabel.text!, numberOfServings: self.recipeServingsLabel.text!,
                             recipeImage: recipeImageView,recipeIngredients: self.recipeIngredientLabel.text!,
                             recipeInstructions: self.recipeInstructionsLabel.text!)
    }
    
    func saveRecipeToCoreData(recipeId : Int , recipeTitle : String , recipeTime :String , numberOfServings :String ,
                              recipeImage :UIImageView ,  recipeIngredients : String ,recipeInstructions :String)
    {
        let recipeInfo = RecipeDB(context: dataController.viewContext)
        
        recipeInfo.recipeId = Int32(recipeId)
        recipeInfo.recipeTitle = recipeTitle
        recipeInfo.recipeTime = recipeTime
        recipeInfo.numberOfServings = numberOfServings
        recipeInfo.recipeImage = recipeImage.image?.pngData()
        recipeInfo.recipeIngredients = recipeIngredients
        recipeInfo.recipeInstructions = recipeInstructions
        
        do
        {
            try dataController.viewContext.save()
            print("The Recipe is saved to Core data ")
            
            DispatchQueue.main.async
            {
                Alert.globalAlert(title: "Save Complete ", message: "The Recipe is saved to your List ", viewController: self)
            }
        }
        catch
        {
            print("Cant save the data : ",error.localizedDescription)
            
            DispatchQueue.main.async
            {
                Alert.globalAlert(title: "Error ", message: error.localizedDescription , viewController: self)
            }
            
        }
    }
}

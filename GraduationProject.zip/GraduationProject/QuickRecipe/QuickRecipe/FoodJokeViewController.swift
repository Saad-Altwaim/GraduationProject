//
//  FoodJokeViewController.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/4/23.
//

import UIKit

class FoodJokeViewController: UIViewController
{
    @IBOutlet weak var label: UILabel!
    var jokeText = ""
    override func viewDidLoad()
    {
        super.viewDidLoad()

        navigationItem.title = "Food Joke for Today"
        
        displaySpoonacularApiClientForFoodJoke()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController!.navigationBar.topItem?.title = "Food Joke"
        BarButton.barButton(viewController: self , Enabled :false , color :UIColor.clear)
    }
    
    func displaySpoonacularApiClientForFoodJoke()
    {
        SpoonacularApiClient.foodJoke
        {
            (result, error) in
            self.jokeText = result?.text ?? "Sorry for this Error"
            if (self.jokeText == "" || error != nil)
            {
                DispatchQueue.main.async
                {
                    Alert.globalAlert(title: "Error", message: "Cant Load form the Web", viewController: self)
                }
            }
        
            else
            {
                DispatchQueue.main.async
                {
                    self.label.text = self.jokeText
                }
            }
        }
    }
}

//
//  SavedDataViewController.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 2/20/23.
//

import UIKit
import CoreData

class SavedDataViewController: UIViewController , UITableViewDelegate , UITableViewDataSource , NSFetchedResultsControllerDelegate
{
    @IBOutlet weak var tableview: UITableView!
    
    var fetchedResultsController : NSFetchedResultsController<RecipeDB>!
    var dataController : DataController!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        tableview.delegate = self
        tableview.dataSource = self
        
        setUpFetchedResultsController()
        recipeMessage()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController!.navigationBar.topItem?.title = "Your Recipe List"
        BarButton.barButton(viewController: self , Enabled :false , color :UIColor.clear)
    }
    
    func deleteRecipe(at indexPath: IndexPath)
    {
        let recipeToDelete = fetchedResultsController.object(at: indexPath)
        
        dataController.viewContext.delete(recipeToDelete)
        try? dataController.viewContext.save()
    }
    
    func recipeMessage()
    {
        let fetchRequest : NSFetchRequest<RecipeDB> = RecipeDB.fetchRequest()
          
        if let result = try? dataController?.viewContext.fetch(fetchRequest)
        {
            if (result.count == 0)
            {
                Alert.globalAlert(title: "Empty", message: "you dont have Any saved REcipe ", viewController: self)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if let controller = segue.destination as? RecipeDetailViewController
        {
            if let indexPath = tableview.indexPathForSelectedRow
            {
                controller.recipe = fetchedResultsController.object(at: indexPath)
                controller.dataController = dataController
                controller.coredataChecker = true
            }
        }
    }
    
    // MARK: - UITableView Functions
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return fetchedResultsController.sections?[section].numberOfObjects ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let recipeName = fetchedResultsController.object(at: indexPath)
        let cell = tableview.dequeueReusableCell(withIdentifier: "SavedDataTableViewCell", for: indexPath) as! SavedDataTableViewCell

        cell.textLabel?.text = recipeName.recipeTitle

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        performSegue(withIdentifier: "RecipeDetailSegue", sender: indexPath)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        switch editingStyle {
        case .delete: deleteRecipe(at: indexPath)
        default: ()
        }
    }
    
    // MARK: - NSFetchedResultsController Functions
    fileprivate func setUpFetchedResultsController()
    {
        let fetchRequest : NSFetchRequest<RecipeDB> = RecipeDB.fetchRequest()
        let sortDescriptor  = NSSortDescriptor(key: "recipeId", ascending: false)
        
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest,
        managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        
        fetchedResultsController.delegate = self
        
        do
        {
            try fetchedResultsController.performFetch()
        }
        catch
        {
            fatalError("The Fetch could not be performed: \(error.localizedDescription)")
        }
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>)
    {
        tableview.beginUpdates()
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>)
    {
        tableview.endUpdates()
    }
    
    // Questions
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?,
                    for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?)
    {
        switch type
        {
        case NSFetchedResultsChangeType.delete:
            print("NSFetchedResultsChangeType.Delete detected")
            if let deleteIndexPath = indexPath
            {
                tableview.deleteRows(at: [deleteIndexPath], with: UITableView.RowAnimation.fade)
            }
            default:()
        }
    }
}

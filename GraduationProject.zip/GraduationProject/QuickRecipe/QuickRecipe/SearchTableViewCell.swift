//
//  SearchTableViewCell.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/19/23.
//

import UIKit

class SearchTableViewCell: UITableViewCell
{
    @IBOutlet weak var recipeImageView : LazyDownloadingImage!
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    
    override func prepareForReuse()
    {
        super.prepareForReuse()
        self.recipeImageView.image = nil
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        
        super.setSelected(selected, animated: animated)
    }
}

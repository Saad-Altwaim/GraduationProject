//
//  ViewController.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 12/25/22.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate , UITableViewDataSource , UISearchBarDelegate , UITextFieldDelegate
{
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var numberTextFiled: UITextField!
    
    var dataController : DataController!
        
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        tableView.dataSource       = self
        tableView.delegate         = self
        searchBar.delegate         = self
        numberTextFiled.delegate   = self
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController!.navigationBar.topItem?.title = "Search"
        BarButton.barButton(viewController: self , Enabled :false , color :UIColor.clear)
    }
    
    func displaySpoonacularApiClientForComplexSearchAndmaxReadyTime(query : String , maxReadyTime : Int)
    {
        SpoonacularApiClient.maxReadyTime(query: query, maxReadyTime: maxReadyTime)
        {
            (searchResult, error) in
            
            ComplexSearchDataModel.complexSearchDataList = searchResult

            if (ComplexSearchDataModel.complexSearchDataList == [] || error != nil)
            {
                DispatchQueue.main.async
                {
                    Alert.globalAlert(title: "Error", message: "Cant locate Recipe Name ", viewController: self)
                }
            }

            else
            {
                DispatchQueue.main.async
                {
                    self.tableView.reloadData()
                }
            }
        }
    }
    
    func reloadTableView()
    {
        ComplexSearchDataModel.complexSearchDataList = []
        self.tableView.reloadData()
    }
    // Questions
    
    // MARK: MySearch functions
    func advanceSearchfucntion(searchBar: UISearchBar)
    {
        reloadTableView()
        var time = Int(numberTextFiled.text!) ?? 0
        if (time > 0)
        {
            searchBar.resignFirstResponder()
            if let text = searchBar.text
            {
                self.tableView.reloadData()
                displaySpoonacularApiClientForComplexSearchAndmaxReadyTime(query: text, maxReadyTime:time )
            }
        }
        else
        {
            time = 0
            searchBar.resignFirstResponder()
            if let text = searchBar.text
            {
                self.tableView.reloadData()
                displaySpoonacularApiClientForComplexSearchAndmaxReadyTime(query: text, maxReadyTime:time )
            }
        }
    }
    
    // MARK: UIStoryboardSegue functions
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "RecipeDetailSegue")
        {
            guard let controller = segue.destination as? RecipeDetailViewController else { return }
            let recipeDetail = ComplexSearchDataModel.complexSearchDataList[(self.tableView.indexPathForSelectedRow?.item)!]
            controller.recipeName = recipeDetail.title
            controller.recipeImage = recipeDetail.image
            controller.recipeId = recipeDetail.id
            controller.dataController = dataController
            controller.coredataChecker = false

        }
    }
    
    // MARK: UISearchBar functions
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        advanceSearchfucntion(searchBar: searchBar)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        reloadTableView()
    }
    
    // Questions
    // MARK: UITextField functions
    // this functions is to restrict UITextField to take only numbers And limit the number of characters to 4
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        //restrict UITextField to take only numbers
        if textField == numberTextFiled
        {
            let allowedCharacters   = "0123456789"
            let allowedCharacterSet = CharacterSet(charactersIn: allowedCharacters)
            let typeCharacterIn     = CharacterSet(charactersIn: string)
            let numbers = allowedCharacterSet.isSuperset(of: typeCharacterIn)
            
            // limit the number of characters to 4
            let currentText = numberTextFiled.text ?? ""
            guard let numberRange = Range(range, in: currentText) else { return false }
            let updateText = currentText.replacingCharacters(in: numberRange, with: string)
            if updateText.count == 4
            {
                return updateText.count < 4
            }
            
            return numbers
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        advanceSearchfucntion(searchBar: searchBar)
        return true
    }

    // MARK: UITableView functions
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return ComplexSearchDataModel.complexSearchDataList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchTableViewCell", for: indexPath) as! SearchTableViewCell
        let dataModel = ComplexSearchDataModel.complexSearchDataList[indexPath.row]
        let urlString = dataModel.image
        let imageURL = URL(string: urlString)
        
        cell.recipeImageView!.image = UIImage(named: "placeholder")
        cell.recipeImageView.loadImage(fromURL: imageURL!, placeHolderImage: "placeholder")
        cell.titleLabel.text = dataModel.title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        performSegue(withIdentifier: "RecipeDetailSegue", sender: indexPath)
    }
}


//
//  DownloadImageClass.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/12/23.
//

import Foundation
import UIKit

class LazyDownloadingImage : UIImageView 
{
    private let imageCache = NSCache<AnyObject , UIImage>() 
    
    func loadImage(fromURL imageURL : URL , placeHolderImage : String )
    {
        self.image = UIImage(named : placeHolderImage)
        
        if let cachedImage = self.imageCache.object(forKey : imageURL as AnyObject)
        {
            debugPrint("image are loaded from cache for = \(imageURL)")
            self.image = cachedImage
            
            return
        }
        
        let queue = DispatchQueue.global()
        var item: DispatchWorkItem?
        
        item = DispatchWorkItem
        {
            [weak self] () -> Void in
            if let iamgeData = try? Data(contentsOf : imageURL)
            {
                if let image = UIImage(data : iamgeData)
                {
                    self?.imageCache.setObject(image , forKey : imageURL as AnyObject)
                    DispatchQueue.main.async
                    {
                        self?.image = image
                    }
                }
            }
        }
        
        queue.async(execute: item!)
        queue.asyncAfter(deadline: .now() + 0.2)
        {
            item?.cancel()
            item = nil
            self.imageCache.removeAllObjects()
        }
    }
}



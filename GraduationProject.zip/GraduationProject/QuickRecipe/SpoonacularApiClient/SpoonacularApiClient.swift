//
//  SpoonacularApiClient.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 12/25/22.
//

import Foundation

class SpoonacularApiClient
{
    static let apiKey = "6f69e6b82c6541ef85e94f6ba4000462"
    
    enum points
    {
        static let baseURL = "https://api.spoonacular.com/"
        static let apiKeyPram = "?apiKey=\(SpoonacularApiClient.apiKey)"
        
        case random
        case foodJoke
        case maxReadyTime(String , Int)
        case instructions(Int)
        case ingredients(Int)
        
        var stringValue : String
        {
            switch self
            {

                case .random:
                    return points.baseURL + "recipes/random" + points.apiKeyPram + "&number=60"
                case .foodJoke:
                    return points.baseURL + "food/jokes/random" + points.apiKeyPram
                case .maxReadyTime(let query, let maxReadyTime):
                    return points.baseURL + "recipes/complexSearch" + points.apiKeyPram + "&query=\(query)&maxReadyTime=\(maxReadyTime)&number=50"
                case .instructions(let id): // this  instructions for complexSearch - use for Detail view
                    return points.baseURL + "recipes/\(id)/information" + points.apiKeyPram
                case .ingredients(let id): // OR use Get Recipe Card - use for Detail view for random
                    return points.baseURL + "recipes/\(id)/ingredientWidget.json" + points.apiKeyPram
            }
        }
        
        var url :URL
        {
            return URL(string: stringValue)!
        }
    }
    
    class func random(completion : @escaping([RandomRecipesResponse] , Error?) ->Void)
    {
        let task = URLSession.shared.dataTask(with: points.random.url)
        {
            data , response ,error in
            guard let Data = data
            else
            {
                completion([] , error)
                print("Error IN random")
                return
            }
            
            do
            {
                let decoder = JSONDecoder()
                let resultObject = try decoder.decode(RandomRecipesResponseResults.self, from: Data)
                completion(resultObject.recipesResults , error)
            }
            
            catch
            {
                print(error)
                print("Error In the Catch from random")
                completion([],error)
            }
        }
        task.resume()
    }
    
    class func foodJoke(completion : @escaping(FoodJokeResponse? , Error?) ->Void)
    {
        let task = URLSession.shared.dataTask(with: points.foodJoke.url)
        {
            data , response , error in
            guard let Data = data
            else
            {
                completion(nil , error)
                print("Error IN foodJoke")
                return
            }
            
            do
            {
                let decoder = JSONDecoder()
                let resultObject = try decoder.decode(FoodJokeResponse.self, from: Data)
                completion(resultObject , error)
            }
            
            catch
            {
                print(error)
                print("Error In the Catch from foodJoke")
                completion(nil,error)
            }
        }
        task.resume()
    }
    
    // Page 31
    class func maxReadyTime(query :String , maxReadyTime:Int ,completion : @escaping([ComplexSearchResponse] , Error?) -> Void)
    {
        let task = URLSession.shared.dataTask(with: points.maxReadyTime(query, maxReadyTime).url)
        {
            data,response,error in
            guard let Data = data
            else
            {
                completion([],error)
                print("Error IN maxReadyTime")
                print(error!)
                return
            }
            
            do
            {
                let decoder = JSONDecoder()
                let resultObject = try decoder.decode(ComplexSearchResponseResults.self, from: Data)
                completion(resultObject.results , error)
            }
            
            catch
            {
                print(error)
                print("Error In the Catch from maxReadyTime")
                completion([] , error)
            }
        }
        task.resume()
    }
    
    class func instructions(recipeId :Int , completion : @escaping(InstructionsResponse? , Error?) ->Void)
    {
        let task = URLSession.shared.dataTask(with: points.instructions(recipeId).url)
        {
            data , response , error in
            guard let Data = data
            else
            {
                completion(nil , error)
                print("Error IN instructions")
                return
            }
            
            do
            {
                let decoder = JSONDecoder()
                let resultObject = try decoder.decode(InstructionsResponse.self, from: Data)
                completion(resultObject , error)
            }
            
            catch
            {
                print(error)
                print("Error In the Catch from instructions")
                completion(nil,error)
            }
        }
        task.resume()
    }
    
    class func ingredients(recipeId :Int , completion : @escaping([IngredientsResponse] , Error?) ->Void)
    {
        let task = URLSession.shared.dataTask(with: points.ingredients(recipeId).url)
        {
            data , response , error in
            guard let Data = data
            else
            {
                completion([] , error)
                print("Error IN Ingredients")
                return
            }
            
            do
            {
                let decoder = JSONDecoder()
                let resultObject = try decoder.decode(IngredientsResponseResult.self, from: Data)
                completion(resultObject.ingredients , error)
            }
            
            catch
            {
                print(error)
                print("Error In the Catch from Ingredients")
                completion([],error)
            }
        }
        task.resume()
    }
}

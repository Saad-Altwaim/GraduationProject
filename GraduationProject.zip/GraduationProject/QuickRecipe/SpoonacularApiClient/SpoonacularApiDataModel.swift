//
//  SpoonacularApiDataModel.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/5/23.
//

import Foundation

class RandomDataModel
{
    static var randomDataList = [RandomRecipesResponse]()
}

class ComplexSearchDataModel
{
    static var complexSearchDataList = [ComplexSearchResponse]()
}

class IngredientsDataModel
{
    static var IngredientsDataList = [IngredientsResponse]()
    
}

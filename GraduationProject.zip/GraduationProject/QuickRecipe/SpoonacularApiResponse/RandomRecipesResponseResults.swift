//
//  RandomRecipesResponseResults.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 12/30/22.
//

import Foundation

struct RandomRecipesResponseResults : Codable , Equatable
{
    let recipesResults : [RandomRecipesResponse]
    
    enum CodingKeys : String , CodingKey
    {
        case recipesResults = "recipes"
    }
}

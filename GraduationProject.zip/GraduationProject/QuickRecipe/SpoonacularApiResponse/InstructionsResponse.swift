//
//  InstructionsResponse.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/1/23.
//

import Foundation

struct InstructionsResponse : Codable ,Equatable
{
    let readyInMinutes : Int
    let servings : Int
    let instructions : String
    
    enum CodingKeys : String , CodingKey
    {
        case instructions
        case readyInMinutes
        case servings
    }
}

//
//  ComplexSearchResponseResults.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 12/26/22.
//

import Foundation

struct ComplexSearchResponseResults : Codable , Equatable
{
    let results : [ComplexSearchResponse]
    
    enum CodingKeys : String , CodingKey
    {
        case results
    }
}

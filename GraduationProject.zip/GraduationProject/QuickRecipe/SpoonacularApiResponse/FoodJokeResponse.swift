//
//  FoodJokeResponse.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 12/31/22.
//

import Foundation

struct FoodJokeResponse : Codable ,Equatable
{
    let text : String
    
    enum CodingKeys : String , CodingKey
    {
        case text
    }
}

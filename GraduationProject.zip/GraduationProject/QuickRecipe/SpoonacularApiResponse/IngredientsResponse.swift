//
//  IngredientsResponse.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/1/23.
//

import Foundation

struct IngredientsResponse : Codable , Equatable
{
    let name : String
    let amount : Amount
    
    enum CodingKeys : String ,CodingKey
    {
        case name
        case amount
    }
}

struct Amount : Codable , Equatable
{
    let metric : Metric

    enum CodingKeys : String , CodingKey
    {
        case metric
    }
}

struct Metric : Codable , Equatable
{
    let value : Double
    let unit  : String

    enum CodingKeys : String , CodingKey
    {
        case value
        case unit
    }
}

// the URL to test this response
// please see -> InstructionsResponseResult
// (https://api.spoonacular.com/recipes/634585/ingredientWidget.json?apiKey=6f69e6b82c6541ef85e94f6ba4000462)

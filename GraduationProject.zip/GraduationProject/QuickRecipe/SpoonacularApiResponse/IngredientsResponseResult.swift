//
//  InstructionsResponseResult.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/1/23.
//

import Foundation

struct IngredientsResponseResult : Codable , Equatable
{
    let ingredients : [IngredientsResponse]
    
    enum CodingKeys : String , CodingKey
    {
        case ingredients

    }
}


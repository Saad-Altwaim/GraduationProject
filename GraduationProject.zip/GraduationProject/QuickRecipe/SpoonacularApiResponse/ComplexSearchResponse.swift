//
//  complexSearchResponse.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 12/26/22.
//

import Foundation

struct ComplexSearchResponse :Codable , Equatable
{
    let id    : Int
    let title : String
    let image : String
    
    enum CodingKeys : String , CodingKey
    {
        case id
        case title
        case image
    }
    
}

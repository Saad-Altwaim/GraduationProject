//
//  RandomRecipesResponse.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 12/30/22.
//

import Foundation

struct RandomRecipesResponse : Codable , Equatable
{
    let id             : Int
    let title          : String
    let readyInMinutes : Int
    let image          : String
    
    enum CodingKeys : String , CodingKey
    {
        case id
        case title
        case readyInMinutes
        case image
    }
}

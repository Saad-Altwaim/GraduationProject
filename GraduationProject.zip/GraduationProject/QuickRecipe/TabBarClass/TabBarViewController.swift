//
//  TabBarViewController.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 2/19/23.
//

import Foundation
import UIKit

class TabBarViewController :UITabBarController
{
    let datacontroller = DataController(modelName: "QuickRecipe")
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        setUpChildViewController()
    }
    // Questions
    private func setUpChildViewController()
    {
        guard let viewController = viewControllers else { return }
        
        for viewController in viewController
        {
            switch viewController
            {
                case let randomRecipesViewController as RandomRecipesViewController :
                    randomRecipesViewController.dataController = datacontroller
                    getCoredataLoad()
                    
                case let viewController as ViewController :
                    viewController.dataController = datacontroller
                    
                case let savedDataViewController as SavedDataViewController :
                    savedDataViewController.dataController = datacontroller
                    
                default:
                    break
            }
        }
    }
    
    func getCoredataLoad()
    {
        datacontroller.load()
    }
}


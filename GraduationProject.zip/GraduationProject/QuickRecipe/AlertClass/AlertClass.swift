//
//  AlertClass.swift
//  QuickRecipe
//
//  Created by Saad altwaim on 1/23/23.
//

import Foundation
import UIKit

class Alert
{
    class func globalAlert(title: String, message: String, viewController: AnyObject)
    {
        let alertVC = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let alertButton = UIAlertAction(title: "OK", style: .default,handler: nil )
        alertVC.addAction(alertButton)
        viewController.present(alertVC,animated: true, completion: nil)
    }
}

class BarButton
{
    class func barButton(viewController: AnyObject , Enabled :Bool , color :UIColor)
    {   // Questions
        viewController.navigationController?.navigationBar.topItem?.rightBarButtonItem?.isEnabled = Enabled
        viewController.navigationController?.navigationBar.topItem?.rightBarButtonItem?.tintColor = color
    }
}


